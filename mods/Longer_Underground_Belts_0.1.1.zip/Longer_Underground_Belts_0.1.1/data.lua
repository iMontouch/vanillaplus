data.raw["underground-belt"]["fast-underground-belt"].max_distance = 7
data.raw["underground-belt"]["express-underground-belt"].max_distance = 9
