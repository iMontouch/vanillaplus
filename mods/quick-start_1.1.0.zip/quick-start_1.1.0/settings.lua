data:extend({
  {
    type = "string-setting",
    name = "quick-start-kit",
    order = "aa",
    setting_type = "startup",
    default_value = "medium",
    allowed_values =  {"small", "medium", "big"}
  }
})