return {
  ["ammo-dytech-laser"]           = {"laser-clip-1", "laser-clip-2", "laser-clip-3"},
  ["ammo-dytech-laser-tank"]      = {"battery-tank"},
  ["ammo-dytech-laser-shotgun"]   = {"laser-clip-shotgun-1", "laser-clip-shotgun-2", "laser-clip-shotgun-3"},
  ["ammo-dytech-sniper"]          = {"sniper-magainze"},
  ["ammo-dytech-capsule"]         = {
    "acid-capsule-ammo-1",      "acid-capsule-ammo-2",      "acid-capsule-ammo-3",
    "napalm-capsule-ammo-1",    "napalm-capsule-ammo-2",    "napalm-capsule-ammo-3",
    "firestorm-capsule-ammo-1", "firestorm-capsule-ammo-2", "firestorm-capsule-ammo-3",
    "poison-capsule-ammo-1",    "poison-capsule-ammo-2",    "poison-capsule-ammo-3",
    "radiation-capsule-ammo-1", "radiation-capsule-ammo-2", "radiation-capsule-ammo-3",
  },
}
