--
-- Disclaimer: mp warranty void if edited.
--

return {
["combat-units"] = {"destroyer-unit-ammo", "defender-unit-ammo", "distractor-unit-ammo"}, --Combat Units
["mo-ammo-goliath"] = {"mega-cannon-shell"}, --MoMods
["at-artillery-mk1-shell"] = {"Artillery_mk1_Ammo"}, --Additional Turret
["at-artillery-mk2-shell"] = {"Artillery_mk2_Ammo"}, --Additional Turret
}
