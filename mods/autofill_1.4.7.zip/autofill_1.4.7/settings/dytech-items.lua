--advanced-magazines-1 advanced-magazines-2 advanced-magazines-3 advanced-magazines-4 advanced-magazines-5 bullet

return {
  ["ammo-bullets"]      = {
    "advanced-magazines-5", "advanced-magazines-4", "advanced-magazines-3", "advanced-magazines-2", "advanced-magazines-1",
    "acid-magazine-3", "acid-magazine-2", "acid-magazine-1",
    "napalm-magazine-3", "napalm-magazine-2", "napalm-magazine-1",
    "plasma-magazine-3", "plasma-magazine-2", "plasma-magazine-1",
    "poison-magazine-3", "poison-magazine-2", "poison-magazine-1",
  }
}
