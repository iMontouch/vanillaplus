if not UGB_REDUX_CONFIG then UGB_REDUX_CONFIG = {} end

-- Add 6x Belt to recipe
-- true/false
UGB_REDUX_CONFIG.addBeltToRecipe = true