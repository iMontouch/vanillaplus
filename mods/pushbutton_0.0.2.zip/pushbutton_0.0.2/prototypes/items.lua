data:extend{
  {
    type = "item",
    name = "pushbutton",
    icon = "__base__/graphics/icons/constant-combinator.png",
    flags = {"goes-to-quickbar"},
    subgroup = "circuit-network",
    place_result="pushbutton",
    order = "b[combinators]-d[pushbutton]",
    stack_size = 50,
  },
  }
