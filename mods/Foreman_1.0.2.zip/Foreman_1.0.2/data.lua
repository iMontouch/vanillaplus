-- --entity
require("prototypes.style")
require("prototypes.hotkeys")


-- --items
-- require("prototypes.item.items")

-- --recipies
-- require("prototypes.recipe.recipes")