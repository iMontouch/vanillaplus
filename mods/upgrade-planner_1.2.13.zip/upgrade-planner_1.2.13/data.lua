require("prototypes.style")

data:extend({

  {
    type = "selection-tool",
    name = "upgrade-builder",
    icon = "__upgrade-planner__/builder.png",
    stack_size = 1,
    subgroup = "tool",
    order = "c[automated-construction]-d[upgrade-builder]",
    flags = {"goes-to-quickbar"},
    selection_color = {r = 0.2, g = 0.8, b = 0.2, a = 0.2},
    alt_selection_color = {r = 0.2, g = 0.2, b = 0.8, a = 0.2},
    selection_mode = {"buildable-type"},
    alt_selection_mode = {"buildable-type"},
    selection_cursor_box_type = "entity",
    alt_selection_cursor_box_type = "copy"
    
  },
  {
    type = "recipe",
    name = "upgrade-builder",
    enabled = false,
    energy_required = 8,
    ingredients =
    {
      {"deconstruction-planner", 1},
      {"advanced-circuit", 5},
    },
    result = "upgrade-builder"
  },
  {
    type = "technology",
    name = "upgrade-builder",
    icon = "__upgrade-planner__/builder-tech.png",
    icon_size = 64,
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "upgrade-builder"
      },
      
    },
    prerequisites = {"automated-construction"},
    unit =
    {
      count = 150,
      ingredients =
      {
        {"science-pack-1", 1},
        {"science-pack-2", 1}
      },
      time = 30
    },
    upgrade = true,
    order = "c-k-c",
  },
})




















