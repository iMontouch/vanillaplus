local deathMessageTemplates = 
{
  [1] = {[1] = "", [2] = " took a long walk off a short pier."},
  [2] = {[1] = "", [2] = " realized their requirements for survival much too late."},
  [3] = {[1] = "Oh noes! ", [2] = " was too stupid to continue living."},
  [4] = {[1] = "", [2] = " became a martyr."},
  [5] = {[1] = "Pieces of ", [2] = " fly past your face in slow motion."},
  [6] = {[1] = "Natural selection didn't choose ", [2] = "."},
  [7] = {[1] = "It's time to bury ", [2] = " again."},
  [8] = {[1] = "Looks like ", [2] = " will be needing a new set of Power Armor."},
  [9] = {[1] = "Want to see how not to do it?  Check out the shining example from ", [2] = "."},
  [10] = {[1] = "", [2] = " found a really quick way back to the spawn."},
  [11] = {[1] = "", [2] = " died, what a dumbass."},
  [12] = {[1] = "", [2] = " was caught with their pants down."},
  [13] = {[1] = "", [2] = " stepped on a grenade."},
  [14] = {[1] = "", [2] = " was processed for science."},
  [15] = {[1] = "", [2] = " forgot to breath."},
  [16] = {[1] = "", [2] = " stubbed their toe."},
  [17] = {[1] = "", [2] = " tripped over a biter."},
  [18] = {[1] = "", [2] = " choked on a fly."},
  [19] = {[1] = "There was an accident during ", [2] = "\'s rectal exam."},
  [20] = {[1] = "", [2] = " thought he was Chuck Norris."},
  [21] = {[1] = "You watch ", [2] = "\'s soul rise from his body."},
  [22] = {[1] = "", [2] = " has an explosive personality."},
  [23] = {[1] = "", [2] = " \'s sacrifice has pleased the train gods."},
  [24] = {[1] = "You stand idly by getting ready for an attack as ", [2] = "runs in screaming leeeeeeeeroy jenkins!!!!!"},
}

function printToAllPlayers(message)
  for k,player in pairs(game.players) do
    if player.connected then
      player.print(message)
    end
  end
end

function generateDeathMessage(playerName)
  local i = math.random(1,24)
  return deathMessageTemplates[i][1] .. playerName .. deathMessageTemplates[i][2]
end


script.on_event(defines.events.on_player_died, function(event)
    for k,player in pairs(game.players) do
          printToAllPlayers(generateDeathMessage(game.players[event.player_index].name))
          break
    end
end)