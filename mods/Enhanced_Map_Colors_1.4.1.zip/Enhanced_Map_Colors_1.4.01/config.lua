--nothing to see here

--[[ --IGNORE THIS CODE
Belt_Overlay_Functionality = false -- Use either true or false value. When set to true, any save game will take longer to load, may take too long
--]]