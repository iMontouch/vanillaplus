data:extend({
  {
    type = "recipe",
    name = "chainsaw",
    enabled = false,
    ingredients =
    {
      {"steel-plate", 3},
      {"iron-plate", 5},
      {"engine-unit", 1},
      {"coal", 20}
    },
    result = "chainsaw",
    requester_paste_multiplier = 4
  }
})
